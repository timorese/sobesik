<?php
/** Local, responsive illustrative imagery. Never rewrites custom uploads or partner logos. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function b52_image_scenes() {
    return array(
        'sale' => 'Бензовоз Б52 с фирменной символикой и надписью «ОГНЕОПАСНО»',
        'storage' => 'Резервуары и трубопроводы нефтехранилища',
        'azs' => 'Заправочная станция в графитовых и красных тонах',
        'weigh' => 'Грузовой автомобиль на весовой платформе',
        'parking' => 'Организованная стоянка грузовых автомобилей',
        'cement' => 'Фирменный цементовоз Б52',
        'cement-card' => 'Цементовоз Б52 на дороге',
        'base' => 'Территория транспортной базы',
        'about' => 'Бензовоз Б52 — вид сзади',
        'news' => 'Заправочная станция после дождя',
        'contact' => 'Рабочее место с телефоном',
        'office' => 'Документы на рабочем столе промышленной компании',
    );
}

function b52_scene_url( $key, $width ) {
    return add_query_arg( 'v', wp_get_theme()->get( 'Version' ), get_theme_file_uri( 'assets/images/' . $key . '-' . $width . '.webp' ) );
}

function b52_image_attributes( $key ) {
    static $dimensions = null;
    if ( null === $dimensions ) {
        $dimensions = array();
        foreach ( (array) json_decode( file_get_contents( get_theme_file_path( 'assets/images/manifest.json' ) ), true ) as $image ) {
            $dimensions[ $image['scene'] ] = $image['dimensions'];
        }
    }
    $size = $dimensions[ $key ] ?? array( 1536, 1024 );
    $largest = min( 1536, $size[0] );
    $sources = array();
    foreach ( array( 640, 960, 1536 ) as $width ) {
        $sources[] = b52_scene_url( $key, $width ) . ' ' . min( $width, $size[0] ) . 'w';
    }
    return array(
        'src' => b52_scene_url( $key, 1536 ),
        'srcset' => implode( ', ', $sources ),
        'sizes' => '(max-width: 781px) 92vw, (max-width: 1280px) 48vw, 640px',
        'width' => $largest, 'height' => (int) round( $largest * $size[1] / $size[0] ),
        'style' => '--b52-image-ratio:' . (int) $size[0] . '/' . (int) $size[1] . ';',
        'alt' => b52_image_scenes()[ $key ],
        'decoding' => 'async',
    );
}

function b52_scene_image( $key, $eager = false ) {
    $html = '<img';
    foreach ( b52_image_attributes( $key ) as $name => $value ) {
        $html .= ' ' . $name . '="' . esc_attr( $value ) . '"';
    }
    return $html . ' loading="' . ( $eager ? 'eager' : 'lazy' ) . '"' . ( $eager ? ' fetchpriority="high"' : '' ) . '>';
}

/** Map only shipped images or their known importer copies, not arbitrary media. */
function b52_generated_scene_for_url( $url ) {
    $path = wp_parse_url( $url, PHP_URL_PATH );
    $file = basename( (string) $path );
    if ( preg_match( '#/assets/cards/(sale|storage|azs|weigh|parking|cement)\.(?:jpg|webp)$#', (string) $path, $m ) ) { return $m[1]; }
    if ( preg_match( '#/assets/images/(sale|storage|azs|weigh|parking|cement|cement-card|base|office|about|news|contact)-\d+\.webp$#', (string) $path, $m ) ) { return $m[1]; }
    $scenes = array( 'sale'=>'sale', 'storage'=>'storage', 'azs'=>'azs', 'weigh'=>'weigh', 'parking'=>'parking', 'cement'=>'cement', 'gallery1'=>'about', 'gallery2'=>'sale', 'gallery3'=>'cement', 'gallery4'=>'news' );
    $imported = get_option( 'b52_media_map', array() );
    foreach ( b52_data( 'media' ) as $key => $source ) {
        if ( ! isset( $scenes[ $key ] ) ) { continue; } // Preserve documentary news and genuine partner logos.
        if ( $url === $source ) { return $scenes[ $key ]; }
        if ( isset( $imported[ $source ] ) && $url === wp_get_attachment_url( absint( $imported[ $source ] ) ) ) { return $scenes[ $key ]; }
        // Handles the original importer's b52-<hash>-<filename> names and WP scaled copies.
        $original = pathinfo( basename( wp_parse_url( $source, PHP_URL_PATH ) ), PATHINFO_FILENAME );
        if ( preg_match( '#^b52-[a-f0-9]{8}-' . preg_quote( $original, '#' ) . '(?:-scaled|-\d+x\d+)?\.(?:jpg|jpeg|webp)$#i', $file ) ) { return $scenes[ $key ]; }
    }
    return '';
}

add_filter( 'render_block_core/image', function ( $html, $block ) {
    $tags = new WP_HTML_Tag_Processor( $html );
    if ( ! $tags->next_tag( 'IMG' ) ) { return $html; }
    $key = b52_generated_scene_for_url( html_entity_decode( (string) $tags->get_attribute( 'src' ) ) );
    if ( ! $key ) { return $html; }
    if ( 'cement' === $key && preg_match( '/\bb52-service-photo\b/', $block['attrs']['className'] ?? '' ) ) { $key = 'cement-card'; }
    if ( 'azs' === $key ) { $key = 'news'; } // Use the supplied real station photo in service cards.
    foreach ( b52_image_attributes( $key ) as $name => $value ) { $tags->set_attribute( $name, $value ); }
    $tags->set_attribute( 'loading', 'lazy' );
    $tags->add_class( 'b52-scene-' . $key );
    $tags->remove_attribute( 'data-id' );
    $html = $tags->get_updated_html();
    // Remove only theme-owned old captions if an older rendered block was pasted into a page.
    $html = preg_replace( '#<span\b[^>]*class="b52-image-note"[^>]*>Сгенерированная иллюстрация</span>#u', '', $html );
    $html = preg_replace( '#<figcaption\b[^>]*>\s*(?:Сгенерированная иллюстрация)?\s*</figcaption>#u', '', $html );
    return $html;
}, 20, 2 );

add_filter( 'render_block_core/cover', function ( $html, $block ) {
    if ( ! preg_match( '/\bb52-hero\b/', $block['attrs']['className'] ?? '' ) ) { return $html; }
    $tags = new WP_HTML_Tag_Processor( $html );
    if ( ! $tags->next_tag( 'IMG' ) ) { return $html; }
    $src = (string) $tags->get_attribute( 'src' );
    if ( ! preg_match( '#/assets/(?:hero-tanker\.webp|images/sale-\d+\.webp)$#', (string) wp_parse_url( $src, PHP_URL_PATH ) ) ) { return $html; }
    foreach ( b52_image_attributes( 'sale' ) as $name => $value ) { $tags->set_attribute( $name, $value ); }
    $tags->set_attribute( 'sizes', '100vw' );
    $tags->set_attribute( 'loading', 'eager' );
    $tags->set_attribute( 'fetchpriority', 'high' );
    return $tags->get_updated_html();
}, 20, 2 );

// A caption saved manually from version 2.2 is removed from output, not from the database.
add_filter( 'render_block_core/paragraph', function ( $html, $block ) {
    if ( preg_match( '/\bb52-home-image-note\b/', $block['attrs']['className'] ?? '' ) && false !== strpos( $html, 'Сгенерированная иллюстрация' ) ) { return ''; }
    return $html;
}, 20, 2 );

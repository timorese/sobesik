<?php
/** Version 2.4 presentation changes. Stored pages and options are never rewritten. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function b52_empty_block() {
    return array( 'blockName' => null, 'attrs' => array(), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array( '' ) );
}

/** Rewrite children while retaining each parent's serialized HTML and child slots. */
function b52_map_blocks( $blocks, $callback ) {
    foreach ( $blocks as &$block ) {
        $block['innerBlocks'] = b52_map_blocks( $block['innerBlocks'] ?? array(), $callback );
        $block = $callback( $block );
    }
    return $blocks;
}

function b52_is_fuel_block( $block ) {
    if ( 'b52/fuel-prices' === $block['blockName'] ) { return true; }
    if ( 'core/shortcode' === $block['blockName'] && preg_match( '/^\s*\[b52_fuel_prices(?:\s[^\]]*)?\]\s*$/', $block['innerHTML'] ) ) { return true; }
    return 'core/columns' === $block['blockName'] && in_array( preg_match_all( '/class="[^"]*\bb52-price\b[^"]*"/', serialize_block( $block ) ), array( 4, 5 ), true );
}

function b52_is_azs_image( $block ) {
    if ( 'core/image' !== $block['blockName'] ) { return false; }
    $tag = new WP_HTML_Tag_Processor( $block['innerHTML'] );
    return $tag->next_tag( 'IMG' ) && in_array( b52_generated_scene_for_url( html_entity_decode( (string) $tag->get_attribute( 'src' ) ) ), array( 'azs', 'news' ), true );
}

function b52_prepare_azs_layout( $content ) {
    if ( false !== strpos( $content, 'b52-azs-stela-panel' ) ) { return $content; }
    $blocks = parse_blocks( $content );
    $has_image = false;
    b52_map_blocks( $blocks, function ( $block ) use ( &$has_image ) { if ( b52_is_azs_image( $block ) ) { $has_image = true; } return $block; } );
    // A heavily customized page keeps its own layout; full price blocks still use one stele.
    if ( ! $has_image ) { return $content; }
    $blocks = b52_map_blocks( $blocks, function ( $block ) {
        if ( b52_is_fuel_block( $block ) ) { return b52_empty_block(); }
        if ( 'core/group' === $block['blockName'] && preg_match( '/\bb52-prices\b/', $block['attrs']['className'] ?? '' ) ) {
            // Remove only the default price heading/wrappers. Keep any editor-added copy or links.
            $copy = trim( html_entity_decode( wp_strip_all_tags( serialize_block( $block ) ) ) );
            if ( '' === $copy || 'Цены на топливо' === $copy ) { return b52_empty_block(); }
        }
        return $block;
    } );
    $placed = false;
    $blocks = b52_map_blocks( $blocks, function ( $block ) use ( &$placed ) {
        if ( ! $placed && b52_is_azs_image( $block ) ) {
            $placed = true;
            $new = parse_blocks( '<!-- wp:group {"className":"b52-azs-stela-panel","layout":{"type":"constrained"}} --><div class="wp-block-group b52-azs-stela-panel"><!-- wp:heading {"level":2} --><h2 class="wp-block-heading">Цены на топливо</h2><!-- /wp:heading --><!-- wp:b52/fuel-prices {"variant":"stela"} /--></div><!-- /wp:group -->' );
            return $new[0];
        }
        return $block;
    } );
    return serialize_blocks( $blocks );
}
function b52_azs_content_layout( $content ) {
    if ( is_admin() || ! is_singular() || 'azs' !== b52_current_page_key() || get_the_ID() !== get_queried_object_id() ) { return $content; }
    return b52_prepare_azs_layout( $content );
}
add_filter( 'the_content', 'b52_azs_content_layout', 8 );

// Use the supplied compact vector mark, including in previously saved template parts.
add_filter( 'render_block_core/image', function ( $html ) {
    $tag = new WP_HTML_Tag_Processor( $html );
    if ( ! $tag->next_tag( 'IMG' ) ) { return $html; }
    $path = wp_parse_url( (string) $tag->get_attribute( 'src' ), PHP_URL_PATH );
    if ( ! preg_match( '#/assets/(logo-header(?:-white)?)\.(?:svg|png)$#', (string) $path, $match ) ) { return $html; }
    $tag->set_attribute( 'src', get_theme_file_uri( 'assets/' . $match[1] . '.svg' ) );
    $tag->remove_attribute( 'srcset' );
    $tag->set_attribute( 'width', 520 );
    $tag->set_attribute( 'height', 185 );
    $tag->remove_class( 'b52-original-logo' );
    $tag->add_class( 'b52-vector-logo' );
    return $tag->get_updated_html();
}, 30 );

add_filter( 'render_block_core/group', function ( $html, $block ) {
    $classes = $block['attrs']['className'] ?? '';
    if ( preg_match( '/\bb52-gallery\b/', $classes ) && in_array( b52_current_page_key(), array( 'home', 'about' ), true ) ) {
        $html = str_replace( array( 'НЕФТЕБАЗА И АЗС', 'Вот так выглядит наша нефтебаза и АЗС' ), array( 'АВТОПАРК И АЗС', 'Транспорт и АЗС Б-52' ), $html );
    }
    return $html;
}, 30, 2 );

// Keep the homepage photograph; only normalize the old forced heading line breaks.
add_filter( 'render_block_core/cover', function ( $html, $block ) {
    if ( ! preg_match( '/\bb52-hero\b/', $block['attrs']['className'] ?? '' ) ) { return $html; }
    return preg_replace_callback( '#<h1\b[^>]*>.*?</h1>#s', function ( $m ) { return preg_replace( '#<br\s*/?>#i', ' ', $m[0] ); }, $html );
}, 30, 2 );

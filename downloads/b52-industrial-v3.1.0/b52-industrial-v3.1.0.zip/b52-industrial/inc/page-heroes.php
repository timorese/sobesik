<?php
/** Non-destructive rendering upgrade for pages already stored in WordPress. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function b52_page_presentations() {
    return array(
        'sale' => array( 'sale', 'Продажа светлых и тёмных нефтепродуктов и сжиженного газа для оптовых и розничных клиентов.' ),
        'storage' => array( 'storage', 'Ответственное хранение нефтепродуктов на промышленной базе Б-52.' ),
        'azs' => array( 'azs', 'Бензин, дизельное топливо и газ. Информация о топливе, ценах и услугах АЗС Б-52 в Кстово.' ),
        'weigh' => array( 'weigh', 'Взвешивание грузового транспорта на автомобильных весах базы Б-52.' ),
        'parking' => array( 'parking', 'Информация об автостоянке грузовых автомобилей на территории промышленной базы.' ),
        'cement' => array( 'cement', 'Цемент М500 Д0 в мешках и россыпью. Условия продажи и контакты для заказа.' ),
        'base' => array( 'base', 'Нефтепродукты, хранение и услуги для грузового транспорта в Кстовской промзоне.' ),
        'about' => array( 'about', 'Группа компаний Б-52: история, направления деятельности и реквизиты.' ),
        'contact' => array( 'contact', 'Контакты подразделений, адрес базы и форма для обращения в компанию.' ),
        'privacy' => array( 'office', 'Информация об обработке персональных данных и условиях использования сайта.' ),
        'news' => array( 'news', 'События и публикации группы компаний Б-52.' ),
        'news-post' => array( 'office', 'Материал из архива новостей компании. Подлинные фотографии события сохранены в публикации.' ),
    );
}

function b52_current_page_key() {
    $id = get_queried_object_id();
    if ( ! $id || ! is_singular() ) { return ''; }
    $key = get_post_meta( $id, '_b52_import_key', true );
    if ( isset( b52_page_presentations()[ $key ] ) || 'home' === $key ) { return $key; }
    foreach ( get_option( 'b52_import_map', array() ) as $key => $mapped ) {
        if ( (int) $mapped === $id ) { return $key; }
    }
    $post = get_post( $id );
    foreach ( b52_data( 'pages' ) as $page ) {
        if ( $page['type'] === $post->post_type && basename( trim( $page['path'], '/' ) ) === $post->post_name ) { return $page['key']; }
    }
    return '';
}

function b52_hero_grid( $text, $key ) {
    $presentations = b52_page_presentations();
    $p = $presentations[ $key ] ?? array( 'office', '' );
    if ( $p[1] && false === strpos( $text, 'b52-lead' ) ) { $text .= '<p class="b52-lead">' . esc_html( $p[1] ) . '</p>'; }
    return '<div class="b52-title-layout"><div class="b52-title-layout__text">' . $text . '</div></div>';
}

add_filter( 'render_block_core/group', function ( $html, $block ) {
    if ( ! preg_match( '/\bb52-page-title\b/', $block['attrs']['className'] ?? '' ) || false !== strpos( $html, 'b52-title-layout' ) ) { return $html; }
    // Only wrap the existing inner container. Keep user headings, breadcrumbs and any extra content.
    if ( ! preg_match( '#^(.*?<div\b[^>]*\bb52-container\b[^>]*>)(.*)(</div>\s*</div>\s*)$#s', $html, $m ) ) { return $html; }
    $text = $m[2];
    $text = preg_replace( '#<figure\b[^>]*\bb52-split-hero__image\b[^>]*>.*?</figure>#s', '', $text );
    $breadcrumb = '';
    if ( preg_match( '#<p\b[^>]*\bb52-breadcrumb\b[^>]*>.*?</p>#s', $text, $b ) ) {
        $breadcrumb = $b[0];
        $text = str_replace( $b[0], '', $text );
    }
    return $m[1] . $breadcrumb . b52_hero_grid( $text, b52_current_page_key() ) . $m[3];
}, 25, 2 );

// Generic templates get the same header; imported pages retain their own title block.
add_action( 'init', function () {
    register_block_type( 'b52/page-hero', array( 'api_version' => 3, 'render_callback' => function () {
        $content = get_post_field( 'post_content', get_queried_object_id() );
        if ( false !== strpos( (string) $content, 'b52-page-title' ) ) { return ''; }
        return '<section class="b52-section b52-page-title"><div class="b52-container"><p class="b52-breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Главная</a></p>' . b52_hero_grid( '<p class="b52-eyebrow">Группа компаний Б-52</p><h1>' . esc_html( get_the_title( get_queried_object_id() ) ) . '</h1>', b52_current_page_key() ) . '</div></section>';
    } ) );
} );

// Recognize only the legacy four/five-price columns; do not rewrite database content.
add_filter( 'render_block_core/columns', function ( $html ) {
    if ( 'azs' === b52_current_page_key() && in_array( preg_match_all( '/class="[^"]*\bb52-price\b[^"]*"/', $html ), array( 4, 5 ), true ) && false === strpos( $html, 'b52-fuel' ) ) {
        return b52_render_fuel_prices( 'stela' );
    }
    return $html;
}, 25 );

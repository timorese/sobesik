/* Content is visible by default. Motion is optional and never blocks navigation. */
(() => {
  const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (preference.matches || !('IntersectionObserver' in window) || !Element.prototype.animate) return;
  const running = new Set();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      const animation = entry.target.animate([
        {opacity: .35, transform: 'translateY(16px)'},
        {opacity: 1, transform: 'translateY(0)'}
      ], {duration: 460, easing: 'cubic-bezier(.2,.7,.2,1)'});
      running.add(animation);
      animation.onfinish = () => running.delete(animation);
    });
  }, {threshold: .12});
  document.querySelectorAll('.b52-service-card, .b52-principle').forEach(element => observer.observe(element));
  preference.addEventListener('change', event => {
    if (!event.matches) return;
    observer.disconnect();
    running.forEach(animation => animation.cancel());
    running.clear();
  });
})();

/* Scroll belongs to the browser. The vehicle is a progressive enhancement. */
(() => {
  'use strict';

  const start = () => {
    const heroes = Array.from(document.querySelectorAll('.b52-hero'))
      .filter(hero => hero.querySelector('.b52-hero-vehicle'));
    if (!heroes.length || !('IntersectionObserver' in window)) return;

    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const states = heroes.map(hero => ({hero, visible: false, top: 0, height: 1, value: ''}));
    let intersection;
    let resize;
    let frame = 0;
    let active = false;
    let measure = true;

    const cancel = () => {
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
    };

    const render = () => {
      frame = 0;
      if (!active || document.hidden) return;
      const scroll = window.scrollY;
      if (measure) {
        states.forEach(state => {
          const bounds = state.hero.getBoundingClientRect();
          // Store the document position; a sticky header never becomes a new origin.
          state.top = bounds.top + scroll;
          state.height = Math.max(bounds.height, 1);
        });
        measure = false;
      }
      states.forEach(state => {
        if (!state.visible) return;
        const progress = Math.min(1, Math.max(0, (scroll - state.top) / state.height));
        const value = progress.toFixed(4);
        if (state.value === value) return;
        state.value = value;
        state.hero.style.setProperty('--b52-progress', value);
        state.hero.style.setProperty('--b52-drive', value);
      });
    };

    const schedule = () => {
      if (active && !document.hidden && !frame && states.some(state => state.visible)) {
        frame = window.requestAnimationFrame(render);
      }
    };

    const refresh = () => {
      measure = true;
      schedule();
    };

    const visibility = () => {
      if (document.hidden) cancel();
      else refresh();
    };

    const stop = () => {
      active = false;
      cancel();
      if (intersection) intersection.disconnect();
      if (resize) resize.disconnect();
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', refresh);
      window.removeEventListener('pageshow', refresh);
      window.removeEventListener('load', refresh);
      document.removeEventListener('visibilitychange', visibility);
      states.forEach(state => {
        state.visible = false;
        state.value = '';
        state.hero.style.removeProperty('--b52-progress');
        state.hero.style.removeProperty('--b52-drive');
      });
    };

    const enable = () => {
      if (active || preference.matches) return;
      active = true;
      measure = true;
      intersection = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          const state = states.find(item => item.hero === entry.target);
          if (state) state.visible = entry.isIntersecting;
        });
        if (!states.some(state => state.visible)) cancel();
        else refresh();
      });
      states.forEach(state => intersection.observe(state.hero));
      if ('ResizeObserver' in window) {
        resize = new ResizeObserver(refresh);
        states.forEach(state => resize.observe(state.hero));
      }
      window.addEventListener('scroll', schedule, {passive: true});
      window.addEventListener('resize', refresh, {passive: true});
      window.addEventListener('pageshow', refresh);
      window.addEventListener('load', refresh, {once: true});
      document.addEventListener('visibilitychange', visibility);
      // Fonts can change the hero's document position after its first measurement.
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(refresh);
    };

    const updatePreference = () => preference.matches ? stop() : enable();
    if (preference.addEventListener) preference.addEventListener('change', updatePreference);
    else if (preference.addListener) preference.addListener(updatePreference);
    updatePreference();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();

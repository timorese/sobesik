<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once get_theme_file_path( 'inc/importer.php' );
require_once get_theme_file_path( 'inc/form.php' );
require_once get_theme_file_path( 'inc/fuel-prices.php' );
require_once get_theme_file_path( 'inc/images.php' );
require_once get_theme_file_path( 'inc/page-heroes.php' );
require_once get_theme_file_path( 'inc/layout-update.php' );
require_once get_theme_file_path( 'inc/editor-content.php' );
add_action( 'after_setup_theme', function () {
    add_theme_support( 'editor-styles' );
    add_editor_style( array( 'assets/site.css', 'assets/refinement.css', 'assets/modern.css' ) );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'wp-block-styles' );
} );
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'b52-industrial', get_theme_file_uri( 'assets/site.css' ), array(), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_style( 'b52-refinement', get_theme_file_uri( 'assets/refinement.css' ), array( 'b52-industrial' ), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_style( 'b52-modern', get_theme_file_uri( 'assets/modern.css' ), array( 'b52-refinement' ), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_script( 'b52-kinetic', get_theme_file_uri( 'assets/kinetic.js' ), array(), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'b52-motion', get_theme_file_uri( 'assets/motion.js' ), array(), wp_get_theme()->get( 'Version' ), true );
    wp_enqueue_script( 'b52-live-prices', get_theme_file_uri( 'assets/live-prices.js' ), array(), wp_get_theme()->get( 'Version' ), true );
} );
add_action( 'init', function () {
    register_block_pattern_category( 'b52-sections', array( 'label' => 'Б-52 — готовые секции' ) );
    register_block_pattern_category( 'b52-layouts', array( 'label' => 'Б-52 — оформление' ) );
    register_block_style( 'core/group', array( 'name' => 'b52-outline', 'label' => 'Рамка и отступы' ) );
    register_block_style( 'core/columns', array( 'name' => 'b52-tight', 'label' => 'Компактные колонки' ) );
} );
function b52_data( $file ) {
    static $cache = array();
    if ( ! in_array( $file, array( 'pages', 'media' ), true ) ) { return array(); }
    if ( ! isset( $cache[ $file ] ) ) {
        $cache[ $file ] = json_decode( file_get_contents( get_theme_file_path( 'content/' . $file . '.json' ) ), true );
    }
    return is_array( $cache[ $file ] ) ? $cache[ $file ] : array();
}
function b52_page_url( $key ) {
    $map = get_option( 'b52_import_map', array() );
    if ( ! empty( $map[ $key ] ) && get_post( $map[ $key ] ) && 'trash' !== get_post_status( $map[ $key ] ) ) {
        return get_permalink( $map[ $key ] );
    }
    foreach ( b52_data( 'pages' ) as $page ) {
        if ( $page['key'] === $key ) { return home_url( $page['path'] ); }
    }
    return home_url( '/' );
}
function b52_resolve_content( $content ) {
    if ( false !== strpos( $content, '{{category:news}}' ) ) { $content = str_replace( '{{category:news}}', (string) b52_news_category(), $content ); }
    $content = preg_replace_callback( '/\{\{page:([a-z0-9-]+)\}\}/', function ( $m ) { return esc_url( b52_page_url( $m[1] ) ); }, $content );
    $content = preg_replace_callback( '#\{\{asset:([a-zA-Z0-9_./-]+)\}\}#', function ( $m ) {
        return false === strpos( $m[1], '..' ) ? esc_url( get_theme_file_uri( 'assets/' . $m[1] ) ) : '';
    }, $content );
    foreach ( get_option( 'b52_media_map', array() ) as $original => $id ) {
        $url = wp_get_attachment_url( absint( $id ) );
        if ( $url ) { $content = str_replace( $original, esc_url( $url ), $content ); }
    }
    return b52_prepare_content( $content );
}

function b52_news_category() {
    $term = get_term_by( 'slug', 'news', 'category' );
    if ( $term ) { return $term->term_id; }
    if ( ! current_user_can( 'manage_categories' ) ) { return 0; }
    $result = wp_insert_term( 'Новости компании', 'category', array( 'slug' => 'news' ) );
    return is_wp_error( $result ) ? 0 : absint( $result['term_id'] );
}

<?php
/** Keep editor source and public media in sync without rewriting the database on update. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function b52_post_key( $post ) {
    if ( ! $post instanceof WP_Post ) { return ''; }
    $key = get_post_meta( $post->ID, '_b52_import_key', true );
    if ( $key ) { return $key; }
    $key = array_search( $post->ID, array_map( 'intval', get_option( 'b52_import_map', array() ) ), true );
    if ( false !== $key ) { return $key; }
    return 'azs-promko' === $post->post_name ? 'azs' : '';
}

/** Only known theme pictures are replaced; custom uploads, captions and links remain. */
function b52_prepare_content( $content, $key = '' ) {
    if ( 'azs' === $key ) { $content = b52_prepare_azs_layout( $content ); }
    if ( false === strpos( $content, '<!-- wp:' ) ) { return $content; }
    $blocks = b52_map_blocks( parse_blocks( $content ), function ( $block ) {
        $cover = 'core/cover' === $block['blockName'];
        if ( ! $cover && 'core/image' !== $block['blockName'] ) { return $block; }
        $tags = new WP_HTML_Tag_Processor( $block['innerHTML'] );
        if ( ! $tags->next_tag( 'IMG' ) ) { return $block; }
        $src = html_entity_decode( (string) $tags->get_attribute( 'src' ) );
        $scene = b52_generated_scene_for_url( $src );
        if ( $cover ) {
            if ( ! preg_match( '/\bb52-hero\b/', $block['attrs']['className'] ?? '' ) ) { return $block; }
            if ( preg_match( '#/assets/hero-tanker\.webp$#', (string) wp_parse_url( $src, PHP_URL_PATH ) ) ) { $scene = 'sale'; }
        }
        if ( $cover ) {
            // Match the public hero's natural line wrapping in Gutenberg as well.
            $block['innerBlocks'] = b52_map_blocks( $block['innerBlocks'], function ( $child ) {
                if ( 'core/heading' !== $child['blockName'] || 1 !== ( $child['attrs']['level'] ?? 2 ) ) { return $child; }
                $child['innerHTML'] = preg_replace( '#<br\s*/?>#i', ' ', $child['innerHTML'] );
                foreach ( $child['innerContent'] as &$piece ) {
                    if ( is_string( $piece ) ) { $piece = preg_replace( '#<br\s*/?>#i', ' ', $piece ); }
                }
                unset( $piece );
                return $child;
            } );
        }
        if ( ! $scene ) { return $block; }
        if ( 'azs' === $scene ) { $scene = 'news'; }
        if ( 'cement' === $scene && preg_match( '/\bb52-service-photo\b/', $block['attrs']['className'] ?? '' ) ) { $scene = 'cement-card'; }
        $url = b52_scene_url( $scene, 1536 );
        // Change the saved source, not the rendered responsive markup. Core can then
        // parse and serialize the block without the frontend's srcset/style attributes.
        foreach ( $block['innerContent'] as &$chunk ) {
            if ( null === $chunk ) { continue; }
            $image = new WP_HTML_Tag_Processor( $chunk );
            if ( ! $image->next_tag( 'IMG' ) ) { continue; }
            $image->set_attribute( 'src', $url );
            $image->remove_attribute( 'srcset' );
            $image->remove_attribute( 'sizes' );
            $image->remove_attribute( 'data-id' );
            // Core saves explicit sizing as styles. Legacy card width/height HTML
            // attributes without corresponding block attributes fail validation.
            if ( ! $cover && ! isset( $block['attrs']['width'], $block['attrs']['height'] ) ) {
                $image->remove_attribute( 'width' );
                $image->remove_attribute( 'height' );
            }
            // An old imported attachment must not supply its old URL again on save.
            $id = absint( $block['attrs']['id'] ?? 0 );
            if ( $id ) { $image->remove_class( 'wp-image-' . $id ); }
            $chunk = $image->get_updated_html();
        }
        unset( $chunk, $block['attrs']['id'] );
        if ( $cover ) { $block['attrs']['url'] = $url; }
        $block['innerHTML'] = implode( '', array_filter( $block['innerContent'], 'is_string' ) );
        return $block;
    } );
    return serialize_blocks( $blocks );
}

/** Includes Gutenberg's initial REST preload and subsequent editor requests. */
function b52_editor_rest_content( $response, $post, $request ) {
    if ( 'edit' !== $request->get_param( 'context' ) || ! current_user_can( 'edit_post', $post->ID ) ) { return $response; }
    $data = $response->get_data();
    if ( isset( $data['content']['raw'] ) ) {
        $data['content']['raw'] = b52_prepare_content( $data['content']['raw'], b52_post_key( $post ) );
        $response->set_data( $data );
    }
    return $response;
}
foreach ( array( 'page', 'post', 'wp_template', 'wp_template_part' ) as $b52_type ) {
    add_filter( 'rest_prepare_' . $b52_type, 'b52_editor_rest_content', 20, 3 );
}

add_filter( 'the_editor_content', function ( $content ) {
    return b52_prepare_content( $content, b52_post_key( get_post() ) );
} );

// Persist current references when the user saves. No background migrations, resets,
// option writes, or direct database updates; normal WordPress capabilities/nonces apply.
add_filter( 'wp_insert_post_data', function ( $data, $postarr ) {
    if ( ! in_array( $data['post_type'], array( 'page', 'post', 'wp_template', 'wp_template_part' ), true ) ) { return $data; }
    $post = ! empty( $postarr['ID'] ) ? get_post( $postarr['ID'] ) : null;
    $data['post_content'] = wp_slash( b52_prepare_content( wp_unslash( $data['post_content'] ), b52_post_key( $post ) ) );
    return $data;
}, 20, 2 );

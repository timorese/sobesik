<?php
/**
 * Цены на топливо: единый источник данных, страница в админке, блок и шорткод.
 *
 * Хранение: option b52_fuel_prices = [ 'ai92' => 6990, ... ] (цена в копейках, int).
 *           option b52_fuel_prices_meta = [ 'updated' => unix_timestamp_utc, 'user' => user_id ].
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const B52_FUEL_OPTION = 'b52_fuel_prices';
const B52_FUEL_META   = 'b52_fuel_prices_meta';
const B52_FUEL_PAGE   = 'b52-fuel-prices';

/** Марки топлива: ключ => подписи. Порядок = порядок на стеле. */
function b52_fuel_types() {
    $types = array(
        'ai92' => array( 'name' => 'АИ-92', 'small' => 'АИ', 'big' => '92',  'default' => 6990 ),
        'ai95' => array( 'name' => 'АИ-95', 'small' => 'АИ', 'big' => '95',  'default' => 6590 ),
        'dt'   => array( 'name' => 'ДТ',    'small' => '',   'big' => 'ДТ',  'default' => 7000 ),
        'gas'  => array( 'name' => 'ГАЗ',   'small' => '',   'big' => 'ГАЗ', 'default' => 4190 ),
    );
    $stored = get_option( B52_FUEL_OPTION, array() );
    foreach ( $types as $key => &$type ) {
        if ( isset( $stored['_names'][ $key ] ) && b52_valid_fuel_name( $stored['_names'][ $key ] ) ) { $type['name'] = $stored['_names'][ $key ]; }
    }
    unset( $type );
    return $types;
}

function b52_valid_fuel_name( $name ) {
    return is_string( $name ) && 1 === preg_match( '/^[\p{L}\p{N} .+()–—-]{1,24}$/u', $name ) && '' !== trim( $name );
}

/** Текущие цены в копейках. Единственная точка чтения для всего сайта. */
function b52_get_fuel_prices() {
    $stored = get_option( B52_FUEL_OPTION, array() );
    $stored = is_array( $stored ) ? $stored : array();
    $prices = array();
    foreach ( b52_fuel_types() as $key => $type ) {
        $prices[ $key ] = isset( $stored[ $key ] ) && is_numeric( $stored[ $key ] ) ? (int) $stored[ $key ] : $type['default'];
    }
    return $prices;
}

/** Копейки -> «69,90». */
function b52_format_price( $kopecks ) {
    $kopecks = (int) $kopecks;
    return number_format( intdiv( $kopecks, 100 ), 0, '', '' ) . ',' . str_pad( (string) ( $kopecks % 100 ), 2, '0', STR_PAD_LEFT );
}

/** Ввод пользователя («69,9», «69.90», « 70 ») -> копейки или null. Без float. */
function b52_parse_price( $input ) {
    if ( ! is_string( $input ) ) { return null; }
    $value = str_replace( ',', '.', trim( $input ) );
    if ( ! preg_match( '/^(\d{1,3})(?:\.(\d{1,2}))?$/', $value, $m ) ) { return null; }
    $kopecks = (int) $m[1] * 100 + (int) str_pad( isset( $m[2] ) ? $m[2] : '', 2, '0' );
    return ( $kopecks >= 1 && $kopecks <= 99999 ) ? $kopecks : null;
}

function b52_fuel_updated_timestamp() {
    $meta = get_option( B52_FUEL_META, array() );
    return is_array( $meta ) && ! empty( $meta['updated'] ) ? (int) $meta['updated'] : 0;
}

/** Сброс популярных кешей страниц, если плагин установлен. */
function b52_fuel_purge_caches() {
    if ( function_exists( 'wp_cache_clear_cache' ) ) { wp_cache_clear_cache(); }          // WP Super Cache
    if ( function_exists( 'rocket_clean_domain' ) ) { rocket_clean_domain(); }            // WP Rocket
    if ( function_exists( 'w3tc_flush_all' ) ) { w3tc_flush_all(); }                      // W3 Total Cache
    if ( function_exists( 'sg_cachepress_purge_cache' ) ) { sg_cachepress_purge_cache(); } // SiteGround
    if ( has_action( 'litespeed_purge_all' ) ) { do_action( 'litespeed_purge_all' ); }    // LiteSpeed
    if ( function_exists( 'wpfc_clear_all_cache' ) ) { wpfc_clear_all_cache( true ); }    // WP Fastest Cache
    do_action( 'b52_fuel_prices_changed' );
}

/* ---------- Админка ---------- */

add_action( 'admin_menu', function () {
    add_menu_page( 'Цены АЗС', 'Цены АЗС', 'edit_pages', B52_FUEL_PAGE, 'b52_fuel_admin_screen', 'dashicons-chart-line', 58 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( 'toplevel_page_' . B52_FUEL_PAGE !== $hook ) { return; }
    wp_add_inline_style( 'common', '.b52-fuel-admin{max-width:560px}.b52-fuel-admin .form-table th{width:120px;font-size:20px;vertical-align:middle}.b52-fuel-admin input.b52-fuel-input{font-size:26px;font-weight:700;width:150px;padding:6px 10px;text-align:right}.b52-fuel-admin .b52-unit{font-size:16px;margin-left:8px;color:#50575e}.b52-fuel-admin .b52-meta{background:#fff;border-left:4px solid #db1724;padding:12px 16px}' );
} );

add_action( 'admin_post_b52_save_fuel_prices', function () {
    if ( ! current_user_can( 'edit_pages' ) ) { wp_die( 'Недостаточно прав.', '', array( 'response' => 403 ) ); }
    check_admin_referer( 'b52_save_fuel_prices' );
    $back = admin_url( 'admin.php?page=' . B52_FUEL_PAGE );
    $raw = isset( $_POST['b52_price'] ) && is_array( $_POST['b52_price'] ) ? wp_unslash( $_POST['b52_price'] ) : array();
    $new = array();
    $bad = array();
    foreach ( b52_fuel_types() as $key => $type ) {
        $value = isset( $raw[ $key ] ) && is_string( $raw[ $key ] ) ? $raw[ $key ] : '';
        $parsed = b52_parse_price( $value );
        if ( null === $parsed ) { $bad[] = $key; } else { $new[ $key ] = $parsed; }
    }
    $names = array();
    $name_input = isset( $_POST['b52_name'] ) && is_array( $_POST['b52_name'] ) ? wp_unslash( $_POST['b52_name'] ) : null;
    foreach ( b52_fuel_types() as $key => $type ) {
        $name = null === $name_input ? $type['name'] : ( $name_input[ $key ] ?? '' );
        $name = is_string( $name ) ? trim( $name ) : '';
        if ( ! b52_valid_fuel_name( $name ) ) { $bad[] = $key; }
        $names[ $key ] = $name;
    }
    if ( $bad ) {
        set_transient( 'b52_fuel_form_' . get_current_user_id(), array_map( function ( $v ) { return is_string( $v ) ? sanitize_text_field( $v ) : ''; }, array_intersect_key( $raw, b52_fuel_types() ) ), 5 * MINUTE_IN_SECONDS );
        wp_safe_redirect( add_query_arg( array( 'b52_fuel' => 'error', 'bad' => implode( ',', $bad ) ), $back ) );
        exit;
    }
    $current_names = array_map( function ( $t ) { return $t['name']; }, b52_fuel_types() );
    if ( $new === b52_get_fuel_prices() && $names === $current_names && false !== get_option( B52_FUEL_OPTION ) ) {
        wp_safe_redirect( add_query_arg( 'b52_fuel', 'same', $back ) );
        exit;
    }
    $new['_names'] = $names;
    if ( ! update_option( B52_FUEL_OPTION, $new, true ) && get_option( B52_FUEL_OPTION ) !== $new ) {
        wp_safe_redirect( add_query_arg( 'b52_fuel', 'db-error', $back ) );
        exit;
    }
    update_option( B52_FUEL_META, array( 'updated' => time(), 'user' => get_current_user_id() ), true );
    b52_fuel_purge_caches();
    wp_safe_redirect( add_query_arg( 'b52_fuel', 'saved', $back ) );
    exit;
} );

function b52_fuel_admin_screen() {
    if ( ! current_user_can( 'edit_pages' ) ) { wp_die( 'Недостаточно прав.', '', array( 'response' => 403 ) ); }
    $status = isset( $_GET['b52_fuel'] ) && is_string( $_GET['b52_fuel'] ) ? sanitize_key( wp_unslash( $_GET['b52_fuel'] ) ) : '';
    $bad = isset( $_GET['bad'] ) && is_string( $_GET['bad'] ) ? array_intersect( explode( ',', sanitize_text_field( wp_unslash( $_GET['bad'] ) ) ), array_keys( b52_fuel_types() ) ) : array();
    $prices = b52_get_fuel_prices();
    $form = 'error' === $status ? get_transient( 'b52_fuel_form_' . get_current_user_id() ) : false;
    $meta = get_option( B52_FUEL_META, array() );
    $ts = b52_fuel_updated_timestamp();
    $user = $ts && ! empty( $meta['user'] ) ? get_userdata( (int) $meta['user'] ) : false;
    ?>
    <div class="wrap b52-fuel-admin">
        <h1>Цены АЗС</h1>
        <?php if ( 'db-error' === $status ) : ?><div class="notice notice-error"><p>Не удалось записать цены в базу данных. Прежние цены сохранены. Повторите попытку или обратитесь к администратору.</p></div><?php endif; ?>
        <?php if ( 'saved' === $status ) : ?><div class="notice notice-success is-dismissible"><p><strong>Цены сохранены.</strong> Новые значения опубликованы для страницы АЗС.</p></div><?php endif; ?>
        <?php if ( 'same' === $status ) : ?><div class="notice notice-info is-dismissible"><p>Цены не изменились — дата обновления осталась прежней.</p></div><?php endif; ?>
        <?php if ( 'error' === $status ) : ?><div class="notice notice-error"><p><strong>Цены не сохранены.</strong> Введите положительное число от 0,01 до 999,99, например 69,90 или 70. Допустимы точка и запятая. Проверьте выделенные цены и названия топлива (1–24 символа, без HTML).</p></div><?php endif; ?>
        <p>Впишите новые цены за литр и нажмите «Сохранить». Цены сами появятся на странице АЗС и на стеле.</p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="b52_save_fuel_prices">
            <?php wp_nonce_field( 'b52_save_fuel_prices' ); ?>
            <table class="form-table" role="presentation">
            <?php foreach ( b52_fuel_types() as $key => $type ) :
                $value = is_array( $form ) && isset( $form[ $key ] ) ? $form[ $key ] : b52_format_price( $prices[ $key ] );
                $id = 'b52-price-' . $key; ?>
                <tr>
                    <th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $type['name'] ); ?></label></th>
                    <td>
                        <input id="<?php echo esc_attr( $id ); ?>" class="b52-fuel-input" type="text" inputmode="decimal" autocomplete="off" name="b52_price[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" required maxlength="7"<?php echo in_array( $key, $bad, true ) ? ' aria-invalid="true" style="border-color:#d63638"' : ''; ?>>
                        <span class="b52-unit">₽/л</span>
                    </td>
                </tr>
            <?php endforeach; ?>
            </table>
            <details><summary>Названия топлива (необязательно)</summary>
                <p>Обычно менять не требуется. До 24 символов: буквы, цифры, пробелы, точка, скобки, дефис или плюс.</p>
                <?php foreach ( b52_fuel_types() as $key => $type ) : ?>
                    <p><label for="b52-name-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( array( 'ai92'=>'АИ-92', 'ai95'=>'АИ-95', 'dt'=>'ДТ', 'gas'=>'ГАЗ' )[ $key ] ); ?></label><br>
                    <input id="b52-name-<?php echo esc_attr( $key ); ?>" name="b52_name[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $type['name'] ); ?>" maxlength="24" required></p>
                <?php endforeach; ?>
            </details>
            <?php submit_button( 'Сохранить' ); ?>
        </form>
        <p class="b52-meta">
            <?php if ( $ts ) : ?>
                Последнее изменение: <strong><?php echo esc_html( wp_date( 'd.m.Y, H:i', $ts ) ); ?></strong><?php echo $user ? ' · ' . esc_html( $user->display_name ) : ''; ?>
            <?php else : ?>
                Цены ещё не сохранялись: показаны начальные значения из референса, а не подтверждённые текущие цены. Проверьте их перед публикацией.
            <?php endif; ?>
        </p>
    </div>
    <?php
}

/* ---------- Вывод на сайте ---------- */

/** HTML блока. $variant: full | stela | cards. */
function b52_render_fuel_prices( $variant = 'full', $show_updated = true ) {
    $variant = in_array( $variant, array( 'full', 'stela', 'cards' ), true ) ? $variant : 'full';
    $prices = b52_get_fuel_prices();
    $types = b52_fuel_types();
    $ts = b52_fuel_updated_timestamp();
    ob_start();
    ?>
    <div class="b52-fuel b52-fuel--<?php echo esc_attr( $variant ); ?>" data-b52-fuel data-endpoint="<?php echo esc_url( add_query_arg( 'action', 'b52_get_fuel_prices', admin_url( 'admin-ajax.php' ) ) ); ?>">
        <?php if ( 'cards' !== $variant ) : ?>
        <figure class="b52-stela" aria-label="Стела АЗС Б52: цены на топливо">
            <div class="b52-stela__head"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/logo-header-white.svg' ) ); ?>" alt="Б52 — гарант счастливого пути" width="190" height="95" loading="lazy" decoding="async"></div>
            <div class="b52-stela__body">
                <?php foreach ( $types as $key => $type ) : ?>
                <div class="b52-stela__row">
                    <span class="b52-stela__label" data-b52-name="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $type['name'] ); ?></span>
                    <span class="b52-stela__display"><span class="b52-stela__value" data-b52-price="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( b52_format_price( $prices[ $key ] ) ); ?></span><span class="screen-reader-text"> ₽/л</span></span>
                </div>
                <?php endforeach; ?>
            </div>
            <figcaption class="b52-stela__foot">₽ за литр</figcaption>
        </figure>
        <?php endif; ?>
        <?php if ( 'stela' !== $variant ) : ?>
        <ul class="b52-fuel-cards">
            <?php foreach ( $types as $key => $type ) : ?>
            <li class="b52-fuel-card">
                <span class="b52-fuel-card__name" data-b52-name="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $type['name'] ); ?></span>
                <span class="b52-fuel-card__price"><span data-b52-price="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( b52_format_price( $prices[ $key ] ) ); ?></span><span class="b52-fuel-card__unit"> ₽/л</span></span>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <div class="b52-fuel__notes">
            <p class="b52-fuel__disclaimer" data-b52-price-note><?php echo esc_html( b52_fuel_price_note() ); ?></p>
            <?php if ( $show_updated ) : ?><p class="b52-fuel__updated" data-b52-updated><?php echo $ts ? esc_html( 'Цены обновлены: ' . wp_date( 'd.m.Y, H:i', $ts ) ) : ''; ?></p><?php endif; ?>
            <p class="b52-fuel__sync" data-b52-sync role="status" aria-live="polite"></p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode( 'b52_fuel_prices', function ( $atts ) {
    $atts = shortcode_atts( array( 'variant' => 'full', 'updated' => '1' ), $atts, 'b52_fuel_prices' );
    return b52_render_fuel_prices( $atts['variant'], '0' !== $atts['updated'] );
} );

add_action( 'init', function () {
    wp_register_script( 'b52-fuel-block', get_theme_file_uri( 'assets/fuel-block.js' ), array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor', 'wp-components', 'wp-i18n' ), wp_get_theme()->get( 'Version' ), true );
    register_block_type( 'b52/fuel-prices', array(
        'api_version'     => 3,
        'title'           => 'Цены на топливо (стела)',
        'description'     => 'Цены берутся из раздела «Цены АЗС» в меню админки.',
        'category'        => 'widgets',
        'icon'            => 'chart-line',
        'attributes'      => array(
            'variant'     => array( 'type' => 'string', 'default' => 'full' ),
            'showUpdated' => array( 'type' => 'boolean', 'default' => true ),
        ),
        'supports'        => array( 'html' => false, 'align' => array( 'wide', 'full' ) ),
        'editor_script'   => 'b52-fuel-block',
        'render_callback' => function ( $attrs ) {
            $variant = isset( $attrs['variant'] ) && is_string( $attrs['variant'] ) ? $attrs['variant'] : 'full';
            $show = ! isset( $attrs['showUpdated'] ) || (bool) $attrs['showUpdated'];
            return b52_render_fuel_prices( $variant, $show );
        },
    ) );
} );


/** Read-only public endpoint bypasses page caches; writes remain nonce-protected. */
function b52_fuel_price_note() {
    return b52_fuel_updated_timestamp()
        ? 'Цены указаны за литр. Уточните стоимость на АЗС перед заправкой.'
        : 'Начальные значения из референса. Это не подтверждённые текущие цены АЗС.';
}
function b52_fuel_public_data() {
    nocache_headers();
    header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
    $prices = array();
    foreach ( b52_get_fuel_prices() as $key => $value ) { $prices[ $key ] = b52_format_price( $value ); }
    $ts = b52_fuel_updated_timestamp();
    wp_send_json_success( array( 'prices' => $prices, 'names' => array_map( function ( $t ) { return $t['name']; }, b52_fuel_types() ), 'note' => b52_fuel_price_note(), 'updated' => $ts ? 'Цены обновлены: ' . wp_date( 'd.m.Y, H:i', $ts ) : '' ) );
}
add_action( 'wp_ajax_b52_get_fuel_prices', 'b52_fuel_public_data' );
add_action( 'wp_ajax_nopriv_b52_get_fuel_prices', 'b52_fuel_public_data' );

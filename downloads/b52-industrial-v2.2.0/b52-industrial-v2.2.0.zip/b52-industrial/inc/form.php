<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function b52_form_services() {
    return array( 'Продажа нефтепродуктов', 'Автовесы', 'АЗС', 'Ответственное хранение', 'Автостоянка', 'Цемент', 'Другое' );
}
add_shortcode( 'b52_contact_form', function () {
    $uid = wp_unique_id( 'b52-form-' );
    $policy = get_privacy_policy_url();
    $status = isset( $_GET['b52_status'] ) && is_string( $_GET['b52_status'] ) ? sanitize_key( wp_unslash( $_GET['b52_status'] ) ) : '';
    $messages = array( 'sent' => 'Заявка передана почтовой системе. Спасибо за обращение!', 'error' => 'Отправить заявку не удалось. Позвоните нам или напишите на email.', 'invalid' => 'Проверьте обязательные поля и согласие на обработку данных.', 'expired' => 'Обновите страницу и отправьте форму ещё раз.', 'limit' => 'Повторите отправку через минуту.' );
    ob_start();
    ?>
    <form id="<?php echo esc_attr( $uid ); ?>" class="b52-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <?php if ( isset( $messages[ $status ] ) ) : ?><p class="b52-form-status" role="status"><?php echo esc_html( $messages[ $status ] ); ?></p><?php endif; ?>
        <input type="hidden" name="action" value="b52_send_lead">
        <input type="hidden" name="b52_return" value="<?php echo esc_url( get_permalink() ); ?>">
        <?php wp_nonce_field( 'b52_send_lead', 'b52_nonce' ); ?>
        <div class="b52-honeypot" aria-hidden="true"><label>Не заполнять<input type="text" name="b52_website" tabindex="-1" autocomplete="off"></label></div>
        <p><label for="<?php echo esc_attr( $uid ); ?>-name">Ваше ФИО *</label><input id="<?php echo esc_attr( $uid ); ?>-name" name="b52_name" maxlength="120" autocomplete="name" required></p>
        <p><label for="<?php echo esc_attr( $uid ); ?>-phone">Номер телефона *</label><input id="<?php echo esc_attr( $uid ); ?>-phone" name="b52_phone" type="tel" maxlength="40" autocomplete="tel" required></p>
        <p><label for="<?php echo esc_attr( $uid ); ?>-email">Email</label><input id="<?php echo esc_attr( $uid ); ?>-email" name="b52_email" type="email" maxlength="254" autocomplete="email"></p>
        <p><label for="<?php echo esc_attr( $uid ); ?>-service">Какая услуга Вам интересна?</label><select id="<?php echo esc_attr( $uid ); ?>-service" name="b52_service" required><option value="">Выберите услугу</option><?php foreach ( b52_form_services() as $service ) : ?><option value="<?php echo esc_attr( $service ); ?>"><?php echo esc_html( $service ); ?></option><?php endforeach; ?></select></p>
        <p><label for="<?php echo esc_attr( $uid ); ?>-message">Комментарий</label><textarea id="<?php echo esc_attr( $uid ); ?>-message" name="b52_message" rows="2" maxlength="3000"></textarea></p>
        <?php if ( $policy ) : ?>
        <p><label class="b52-consent"><input type="checkbox" name="b52_consent" value="1" required><span>Нажимая на кнопку «Отправить», я соглашаюсь <a href="<?php echo esc_url( $policy ); ?>">на обработку персональных данных</a>.</span></label></p>
        <button type="submit">Отправить заявку ↗</button>
        <?php else : ?><p>Форма пока не настроена. Для связи: <a href="mailto:bazab52@mail.ru">bazab52@mail.ru</a> или <a href="tel:+79871110052">+7 (987) 111-00-52</a>.</p><?php endif; ?>
    </form>
    <?php
    return ob_get_clean();
} );
function b52_send_lead() {
    $field = function ( $name ) { return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : ''; };
    $return = wp_validate_redirect( esc_url_raw( $field( 'b52_return' ) ), home_url( '/' ) );
    $return = preg_replace( '/#.*$/', '', $return );
    $finish = function ( $status ) use ( $return ) {
        wp_safe_redirect( add_query_arg( 'b52_status', $status, remove_query_arg( 'b52_status', $return ) ) . '#contacts' );
        exit;
    };
    if ( ! wp_verify_nonce( $field( 'b52_nonce' ), 'b52_send_lead' ) ) { $finish( 'expired' ); }
    if ( $field( 'b52_website' ) ) { $finish( 'invalid' ); }
    $name = sanitize_text_field( $field( 'b52_name' ) );
    $phone = sanitize_text_field( $field( 'b52_phone' ) );
    $raw_email = trim( $field( 'b52_email' ) );
    $email = sanitize_email( $raw_email );
    $service = sanitize_text_field( $field( 'b52_service' ) );
    $message = sanitize_textarea_field( $field( 'b52_message' ) );
    if ( ! $name || strlen( $name ) > 480 || ! preg_match( '/^[+0-9() .-]{5,40}$/', $phone ) || strlen( preg_replace( '/\D/', '', $phone ) ) < 5 || ( $raw_email && ( ! is_email( $raw_email ) || $email !== $raw_email ) ) || strlen( $message ) > 12000 || ! in_array( $service, b52_form_services(), true ) || '1' !== $field( 'b52_consent' ) || ! get_privacy_policy_url() ) { $finish( 'invalid' ); }
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
    $rate = 'b52_lead_' . hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) );
    if ( get_transient( $rate ) ) { $finish( 'limit' ); }
    set_transient( $rate, 1, MINUTE_IN_SECONDS );
    $headers = array( 'Content-Type: text/plain; charset=UTF-8' );
    if ( $email ) { $headers[] = 'Reply-To: ' . $email; }
    $body = "ФИО: $name\nТелефон: $phone\nEmail: $email\nУслуга: $service\n\nКомментарий:\n$message\n\nСогласие: получено\nДата UTC: " . gmdate( 'c' );
    $recipient = get_option( 'b52_mail_recipient', 'bazab52@mail.ru' );
    if ( ! is_email( $recipient ) ) { $finish( 'error' ); }
    $ok = wp_mail( $recipient, 'Б-52 — заявка с сайта', $body, $headers );
    $finish( $ok ? 'sent' : 'error' );
}
add_action( 'admin_post_nopriv_b52_send_lead', 'b52_send_lead' );
add_action( 'admin_post_b52_send_lead', 'b52_send_lead' );

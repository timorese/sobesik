<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'admin_menu', function () {
    add_theme_page( 'Б-52 — установка сайта', 'Б-52 — установка сайта', 'edit_theme_options', 'b52-setup', 'b52_setup_screen' );
} );
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( 'appearance_page_b52-setup' !== $hook ) { return; }
    wp_enqueue_script( 'b52-setup', get_theme_file_uri( 'assets/setup.js' ), array(), wp_get_theme()->get( 'Version' ), true );
    wp_localize_script( 'b52-setup', 'B52Setup', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'b52_import' ), 'pageCount' => count( b52_data( 'pages' ) ), 'mediaCount' => count( b52_data( 'media' ) ) ) );
} );
function b52_setup_screen() {
    if ( ! current_user_can( 'edit_theme_options' ) ) { return; }
    $map = get_option( 'b52_import_map', array() );
    ?>
    <div class="wrap" style="max-width:1000px">
    <h1>Б-52 — новый сайт</h1>
    <p>Полный макет с содержимым baza-b52.ru. Редактор Gutenberg встроен в WordPress. Рекомендуемая установка — на отдельный тестовый WordPress.</p>
    <h2>1. Создайте страницы</h2>
    <p>Будут созданы 12 страниц, одна запись и служебная родительская страница «Новости». Все материалы сначала сохраняются как черновики. Существующие страницы не перезаписываются. Повторный импорт не отменяет Ваши правки.</p>
    <p>На новом WordPress переименуйте стандартный черновик «Политика конфиденциальности» и его ярлык до импорта. Если адрес уже занят, будет создана отдельная копия. Освободите исходный адрес перед запуском — установщик вернёт его импортированной странице.</p>
    <button type="button" class="button button-primary" data-b52-job="pages">Импортировать страницы</button>
    <h2>2. Перенесите фотографии</h2>
    <p>Перенос 19 исходных файлов в медиатеку нужен для подлинных логотипов партнёров и архивных фотографий. Новые сгенерированные иллюстрации уже находятся в теме. Неперенесённые оригиналы загружаются с baza-b52.ru. Выполните перенос до отключения старого сайта.</p>
    <button type="button" class="button" data-b52-job="media">Скачать / повторить перенос фото</button>
    <pre id="b52-progress" role="status" aria-live="polite" style="white-space:pre-wrap;background:#fff;padding:20px;max-height:300px;overflow:auto">Готово к работе.</pre>
    <h2>3. Проверьте и запустите</h2>
    <p><a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>">Страницы</a> <a class="button" href="<?php echo esc_url( admin_url( 'site-editor.php' ) ); ?>">Редактор дизайна</a></p>
    <p>Начальные цены АЗС взяты из предоставленного референса и не подтверждают текущую стоимость. Для проверки и изменения откройте «Цены АЗС». У автостоянки сохранено «Раздел в разработке». Страница аренды склада в источнике отвечает 404.</p>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="b52_launch"><?php wp_nonce_field( 'b52_launch' ); ?>
        <p><label><input type="checkbox" name="permalinks" value="1"> Настроить постоянные ссылки /%postname%/ (для нового WordPress)</label></p>
        <?php submit_button( 'Опубликовать импортированные страницы и назначить главную', 'primary', 'submit', false ); ?>
    </form>
    <h2>Почта заявок</h2>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="b52_save_mail"><?php wp_nonce_field( 'b52_save_mail' ); ?>
        <label for="b52-recipient">Получатель</label> <input id="b52-recipient" type="email" name="recipient" value="<?php echo esc_attr( get_option( 'b52_mail_recipient', 'bazab52@mail.ru' ) ); ?>" required>
        <?php submit_button( 'Сохранить адрес', 'secondary', 'submit', false ); ?>
    </form>
    <p>Настройте SMTP и проверьте реальную доставку. Заявки не сохраняются в базе: они отправляются через wp_mail. Не используйте для формы кэш HTML дольше 12 часов.</p>
    <h2>Как редактировать</h2>
    <p>Страницы → нужная страница → Изменить. Тексты редактируются кликом, изображения — через «Заменить».
    «+» → «Паттерны / Образцы» → «Б-52 — готовые секции». Порядок секций меняется в «Обзоре документа».
    Шапка, подвал и общие цвета: Внешний вид → Редактор. Исходный логотип и SVG лежат в assets темы.</p>
    <ul><?php foreach ( b52_data( 'pages' ) as $page ) : if ( empty( $map[ $page['key'] ] ) ) { continue; } ?>
        <li><a href="<?php echo esc_url( get_edit_post_link( $map[ $page['key'] ] ) ); ?>"><?php echo esc_html( $page['title'] ); ?></a> — <?php echo esc_html( get_post_status( $map[ $page['key'] ] ) ); ?></li>
    <?php endforeach; ?></ul>
    </div>
    <?php
}
function b52_import_authorize() {
    if ( ! current_user_can( 'edit_theme_options' ) || ! current_user_can( 'edit_pages' ) || ! current_user_can( 'edit_posts' ) ) { wp_send_json_error( array( 'message' => 'Недостаточно прав.' ), 403 ); }
    check_ajax_referer( 'b52_import', 'nonce' );
}
function b52_import_page_at( $index ) {
    $pages = b52_data( 'pages' );
    if ( ! isset( $pages[ $index ] ) ) { return new WP_Error( 'index', 'Неизвестная страница.' ); }
    $item = $pages[ $index ];
    $map = get_option( 'b52_import_map', array() );
    if ( ! empty( $map[ $item['key'] ] ) && get_post( $map[ $item['key'] ] ) && 'trash' !== get_post_status( $map[ $item['key'] ] ) ) { return 'Уже есть: ' . $item['title']; }
    $path = trim( $item['path'], '/' );
    $slug = $path ? basename( $path ) : 'glavnaya-b52';
    $parent = 0;
    if ( 'news' === $item['key'] ) {
        $blog = get_page_by_path( 'blog' );
        if ( $blog ) { $parent = $blog->ID; }
        else {
            $parent = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'draft', 'post_title' => 'Новости', 'post_name' => 'blog', 'post_content' => '<!-- wp:paragraph --><p><a href="' . esc_url( home_url( '/blog/news/' ) ) . '">Новости компании</a></p><!-- /wp:paragraph -->', 'meta_input' => array( '_b52_managed' => 1 ) ), true );
            if ( is_wp_error( $parent ) ) { return $parent; }
            $map['_blog_parent'] = $parent;
        }
    }
    $existing = $path ? get_page_by_path( $path, OBJECT, $item['type'] ) : get_page_by_path( $slug );
    if ( $existing ) { $slug = 'b52-new-' . $slug; }
    $args = array( 'post_type' => $item['type'], 'post_status' => 'draft', 'post_title' => $item['title'], 'post_name' => $slug, 'post_parent' => $parent, 'post_content' => '', 'meta_input' => array( '_b52_managed' => 1, '_b52_import_unbound' => 1, '_b52_source_url' => $item['source'], '_b52_import_key' => $item['key'], '_wp_page_template' => $item['template'] ) );
    if ( 'post' === $item['type'] ) { $args['post_category'] = array( b52_news_category() ); }
    if ( ! empty( $item['date'] ) ) { $args['post_date'] = $item['date']; }
    $id = wp_insert_post( $args, true );
    if ( is_wp_error( $id ) ) { return $id; }
    $map[ $item['key'] ] = $id;
    update_option( 'b52_import_map', $map, false );
    return ( $existing ? 'Создана копия (адрес занят): ' : 'Создан черновик: ' ) . $item['title'];
}
function b52_bind_pages() {
    $map = get_option( 'b52_import_map', array() );
    foreach ( b52_data( 'pages' ) as $item ) {
        $id = isset( $map[ $item['key'] ] ) ? absint( $map[ $item['key'] ] ) : 0;
        if ( ! $id || ! get_post_meta( $id, '_b52_import_unbound', true ) ) { continue; }
        $content = b52_resolve_content( $item['content'] );
        $result = wp_update_post( array( 'ID' => $id, 'post_content' => wp_slash( $content ) ), true );
        if ( is_wp_error( $result ) ) { return $result; }
        delete_post_meta( $id, '_b52_import_unbound' );
    }
    return 'Страницы связаны. Откройте их в редакторе для проверки.';
}
add_action( 'wp_ajax_b52_import_pages', function () {
    b52_import_authorize();
    $index = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : 0;
    $count = count( b52_data( 'pages' ) );
    $result = $index < $count ? b52_import_page_at( $index ) : b52_bind_pages();
    if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); }
    wp_send_json_success( array( 'message' => $result, 'done' => $index >= $count ) );
} );
function b52_replace_imported_urls( $changes ) {
    foreach ( get_option( 'b52_import_map', array() ) as $id ) {
        $post = get_post( absint( $id ) );
        if ( ! $post || ! get_post_meta( $id, '_b52_managed', true ) ) { continue; }
        $updated = strtr( $post->post_content, $changes );
        if ( $updated !== $post->post_content ) { wp_update_post( array( 'ID' => $id, 'post_content' => wp_slash( $updated ) ) ); }
    }
}
function b52_import_media_at( $index ) {
    $urls = array_values( b52_data( 'media' ) );
    if ( ! isset( $urls[ $index ] ) ) { return new WP_Error( 'index', 'Неизвестное изображение.' ); }
    $url = $urls[ $index ];
    if ( 'baza-b52.ru' !== wp_parse_url( $url, PHP_URL_HOST ) || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) ) { return new WP_Error( 'host', 'Недопустимый источник изображения.' ); }
    $map = get_option( 'b52_media_map', array() );
    if ( ! empty( $map[ $url ] ) && wp_get_attachment_url( $map[ $url ] ) ) { return 'Уже в медиатеке: ' . basename( $url ); }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $tmp = download_url( $url, 30 );
    if ( is_wp_error( $tmp ) ) { return $tmp; }
    if ( filesize( $tmp ) > 20 * MB_IN_BYTES ) { wp_delete_file( $tmp ); return new WP_Error( 'size', 'Файл превышает 20 МБ.' ); }
    $mime = wp_get_image_mime( $tmp );
    if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) { wp_delete_file( $tmp ); return new WP_Error( 'type', 'Источник не вернул поддерживаемое изображение.' ); }
    $id = media_handle_sideload( array( 'name' => 'b52-' . substr( md5( $url ), 0, 8 ) . '-' . basename( wp_parse_url( $url, PHP_URL_PATH ) ), 'tmp_name' => $tmp ), 0, 'Из исходного сайта Б-52' );
    if ( is_wp_error( $id ) ) { wp_delete_file( $tmp ); return $id; }
    update_post_meta( $id, '_b52_source_url', $url );
    $map[ $url ] = $id;
    update_option( 'b52_media_map', $map, false );
    b52_replace_imported_urls( array( $url => wp_get_attachment_url( $id ) ) );
    return 'Сохранено: ' . basename( $url );
}
add_action( 'wp_ajax_b52_import_media', function () {
    b52_import_authorize();
    if ( ! current_user_can( 'upload_files' ) ) { wp_send_json_error( array( 'message' => 'Нет прав на загрузку файлов.' ), 403 ); }
    $index = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : 0;
    $result = b52_import_media_at( $index );
    if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); }
    wp_send_json_success( array( 'message' => $result ) );
} );
add_action( 'admin_post_b52_launch', function () {
    if ( ! current_user_can( 'edit_theme_options' ) || ! current_user_can( 'publish_pages' ) || ! current_user_can( 'publish_posts' ) ) { wp_die( 'Недостаточно прав.' ); }
    check_admin_referer( 'b52_launch' );
    $map = get_option( 'b52_import_map', array() );
    $slugs = array();
    foreach ( b52_data( 'pages' ) as $item ) {
        if ( empty( $map[ $item['key'] ] ) || ! get_post( $map[ $item['key'] ] ) ) { wp_die( 'Сначала завершите импорт всех страниц.' ); }
        $post = get_post( $map[ $item['key'] ] );
        if ( get_post_meta( $post->ID, '_b52_import_unbound', true ) || 'trash' === $post->post_status ) { wp_die( 'Импорт не завершён. Повторите импорт страниц.' ); }
        if ( 0 === strpos( $post->post_name, 'b52-new-' ) ) {
            $path = trim( $item['path'], '/' );
            $path = $path ? $path : 'glavnaya-b52';
            $existing = get_page_by_path( $path, OBJECT, $item['type'] );
            if ( $existing && $existing->ID !== $post->ID ) { wp_die( 'Адрес /' . esc_html( $path ) . '/ уже занят. Измените ярлык старой страницы или переместите её в корзину, затем повторите запуск. Импортированные копии и существующий контент сохранены.' ); }
            $slugs[ $post->ID ] = basename( $path );
        }
    }
    $before = array();
    foreach ( $map as $id ) { $before[ $id ] = get_permalink( $id ); }
    foreach ( $map as $id ) {
        if ( get_post_meta( $id, '_b52_managed', true ) ) {
            $args = array( 'ID' => $id, 'post_status' => 'publish' );
            if ( isset( $slugs[ $id ] ) ) { $args['post_name'] = $slugs[ $id ]; }
            $r = wp_update_post( $args, true );
            if ( is_wp_error( $r ) ) { wp_die( esc_html( $r->get_error_message() ) ); }
        }
    }
    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', absint( $map['home'] ) );
    update_option( 'wp_page_for_privacy_policy', absint( $map['privacy'] ) );
    if ( isset( $_POST['permalinks'] ) && '1' === $_POST['permalinks'] ) { update_option( 'permalink_structure', '/%postname%/' ); flush_rewrite_rules(); }
    $changes = array();
    foreach ( $map as $id ) { $changes[ esc_url( $before[ $id ] ) ] = esc_url( get_permalink( $id ) ); }
    b52_replace_imported_urls( $changes );
    wp_safe_redirect( admin_url( 'themes.php?page=b52-setup' ) );
    exit;
} );
add_action( 'admin_post_b52_save_mail', function () {
    if ( ! current_user_can( 'edit_theme_options' ) ) { wp_die( 'Недостаточно прав.' ); }
    check_admin_referer( 'b52_save_mail' );
    $email = isset( $_POST['recipient'] ) && is_string( $_POST['recipient'] ) ? sanitize_email( wp_unslash( $_POST['recipient'] ) ) : '';
    if ( ! is_email( $email ) ) { wp_die( 'Некорректный email.' ); }
    update_option( 'b52_mail_recipient', $email, false );
    wp_safe_redirect( admin_url( 'themes.php?page=b52-setup' ) );
    exit;
} );

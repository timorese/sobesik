(() => {
  const log = document.getElementById('b52-progress');
  const buttons = Array.from(document.querySelectorAll('[data-b52-job]'));
  const append = (s) => { log.textContent += s + '\n'; log.scrollTop = log.scrollHeight; };
  buttons.forEach(button => button.addEventListener('click', async () => {
    buttons.forEach(b => b.disabled = true);
    log.textContent = '';
    const type = button.dataset.b52Job;
    const count = type === 'pages' ? B52Setup.pageCount + 1 : B52Setup.mediaCount;
    let failures = 0;
    for (let index = 0; index < count; index++) {
      try {
        const body = new URLSearchParams({action: 'b52_import_' + type, nonce: B52Setup.nonce, index: String(index)});
        const response = await fetch(B52Setup.ajax, {method: 'POST', credentials: 'same-origin', body});
        const result = await response.json();
        if (!result.success) throw new Error(result.data?.message || 'Ошибка сервера. Обновите страницу и повторите.');
        append(`${index + 1}/${count}: ${result.data.message}`);
      } catch (error) {
        failures++;
        append(`${index + 1}/${count}: ОШИБКА — ${error.message}`);
        if (type === 'pages') break;
      }
    }
    append(failures ? `Ошибок: ${failures}. Причины указаны выше; после исправления можно повторить.` : 'Готово. Обновите страницу, чтобы увидеть ссылки на материалы.');
    buttons.forEach(b => b.disabled = false);
  }));
})();

(function (wp) {
  var el = wp.element.createElement;
  var SSR = wp.serverSideRender;
  var useBlockProps = wp.blockEditor.useBlockProps;
  var InspectorControls = wp.blockEditor.InspectorControls;
  wp.blocks.registerBlockType('b52/fuel-prices', {
    edit: function (props) {
      var a = props.attributes;
      return el('div', useBlockProps(),
        el(InspectorControls, null,
          el(wp.components.PanelBody, { title: 'Цены на топливо' },
            el(wp.components.SelectControl, {
              label: 'Вид', value: a.variant,
              options: [
                { label: 'Стела и карточки', value: 'full' },
                { label: 'Только стела', value: 'stela' },
                { label: 'Только карточки', value: 'cards' }
              ],
              onChange: function (v) { props.setAttributes({ variant: v }); }
            }),
            el(wp.components.ToggleControl, {
              label: 'Показывать время обновления', checked: a.showUpdated,
              onChange: function (v) { props.setAttributes({ showUpdated: v }); }
            }),
            el('p', null, 'Сами цены меняются в меню «Цены АЗС».')
          )
        ),
        el(SSR, { block: 'b52/fuel-prices', attributes: a })
      );
    },
    save: function () { return null; }
  });
})(window.wp);

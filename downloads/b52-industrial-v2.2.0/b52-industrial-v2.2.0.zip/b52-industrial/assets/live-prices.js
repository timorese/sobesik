/* Read fresh public prices even if the page HTML was served from a cache. */
(function () {
  'use strict';
  var roots = document.querySelectorAll('[data-b52-fuel]');
  if (!roots.length) return;
  var busy = false;
  function refresh() {
    if (busy || document.hidden) return;
    busy = true;
    var url = new URL(roots[0].dataset.endpoint, window.location.href);
    url.searchParams.set('_b52', Date.now().toString());
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 10000);
    fetch(url.toString(), {cache: 'no-store', credentials: 'same-origin', signal: controller.signal})
      .then(function (r) { if (!r.ok) throw new Error('unavailable'); return r.json(); })
      .then(function (r) {
        if (!r.success || !r.data || !r.data.prices) throw new Error('invalid');
        var keys = ['ai92', 'ai95', 'dt', 'gas'];
        if (!keys.every(function (k) { return /^\d{1,3},\d{2}$/.test(r.data.prices[k]); })) throw new Error('invalid');
        roots.forEach(function (root) {
          root.querySelectorAll('[data-b52-price]').forEach(function (el) { el.textContent = r.data.prices[el.dataset.b52Price]; });
          root.querySelectorAll('[data-b52-name]').forEach(function (el) { if (r.data.names && typeof r.data.names[el.dataset.b52Name] === 'string') el.textContent = r.data.names[el.dataset.b52Name]; });
          root.querySelectorAll('[data-b52-price-note]').forEach(function (el) { el.textContent = r.data.note; });
          root.querySelectorAll('[data-b52-updated]').forEach(function (el) { el.textContent = r.data.updated; });
          root.querySelector('[data-b52-sync]').textContent = '';
        });
      })
      .catch(function () {
        roots.forEach(function (root) { root.querySelector('[data-b52-sync]').textContent = 'Не удалось проверить обновление цен. Уточните стоимость на АЗС: 8 (83145) 24-6-24.'; });
      })
      .finally(function () { clearTimeout(timer); busy = false; });
  }
  refresh();
  window.addEventListener('pageshow', refresh);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
  setInterval(refresh, 60000);
})();

<?php
/**
 * Title: Б-52 / О компании
 * Slug: b52-industrial/about
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-about","layout":{"type":"constrained"},"backgroundColor":"ink"} -->
<div class="wp-block-group alignfull b52-section b52-about has-ink-background-color has-background"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">02 / О КОМПАНИИ</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Группа<br>компаний Б-52</h2>
<!-- /wp:heading --><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{{page:about}}">О компании ↗</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p>Группа компаний Б-52 основана в 2000 году. Расположена в промзоне города Кстово в непосредственной близости от федеральной трассы М-7 «Волга» и нефтеперерабатывающего завода ЛУКОЙЛ, имеет асфальтированные подъездные пути.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Периметр территории круглосуточно охраняется современными средствами видео-фиксации и квалифицированными сотрудниками.</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><a href="{{page:contact}}">Адрес: Кстовская промзона, район ТЭЦ ↗</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

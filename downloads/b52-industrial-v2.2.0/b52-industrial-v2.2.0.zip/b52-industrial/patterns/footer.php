<?php
/**
 * Title: Б-52 / footer
 * Slug: b52-industrial/footer
 * Categories: b52-layouts
 * Inserter: no
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-footer","layout":{"type":"constrained"},"backgroundColor":"ink"} -->
<div class="wp-block-group alignfull b52-section b52-footer has-ink-background-color has-background"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"width":"150px","sizeSlug":"full","linkDestination":"custom"} -->
<figure class="wp-block-image size-full is-resized"><a href="{{page:home}}"><img src="{{asset:logo-header-white.svg}}" alt="Б52 — гарант счастливого пути" style="width:150px"/></a></figure>
<!-- /wp:image --><!-- wp:paragraph -->
<p>Группа компаний Б-52</p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Кстовская промзона, район ТЭЦ</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Услуги</h3>
<!-- /wp:heading --><!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><a href="{{page:sale}}">Продажа нефтепродуктов</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="{{page:storage}}">Ответственное хранение нефтепродуктов</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="{{page:weigh}}">Автовесы для грузовых автомобилей</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="{{page:azs}}">АЗС «Б52»</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="{{page:parking}}">Автомобильная стоянка грузовых автомобилей</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="{{page:cement}}">Цемент</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Контакты</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Отдел продаж:<br><a href="tel:+79871110052">+7 (987) 111-00-52</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Ответ. хранение:<br><a href="tel:+78314524024">8 (83145) 24-0-24</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>АЗС «Б52»:<br><a href="tel:+78314524624">8 (83145) 24-6-24</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p><a href="mailto:bazab52@mail.ru">bazab52@mail.ru</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --><!-- wp:paragraph {"className":"b52-copyright"} -->
<p class="b52-copyright">© База52. Все права защищены.　 <a href="{{page:privacy}}">Политика конфиденциальности</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

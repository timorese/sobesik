<?php
/**
 * Title: Б-52 / Галерея
 * Slug: b52-industrial/gallery
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-gallery","layout":{"type":"constrained"},"backgroundColor":"ink"} -->
<div class="wp-block-group alignfull b52-section b52-gallery has-ink-background-color has-background"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">НЕФТЕБАЗА И АЗС</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Фотогалерея</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Вот так выглядит наша нефтебаза и АЗС</p>
<!-- /wp:paragraph --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-gallery-image"} -->
<figure class="wp-block-image size-full b52-gallery-image"><img src="https://baza-b52.ru/wp-content/uploads/2019/04/gallery-1.jpg" alt="Нефтебаза и АЗС Б-52"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-gallery-image"} -->
<figure class="wp-block-image size-full b52-gallery-image"><img src="https://baza-b52.ru/wp-content/uploads/2019/04/gallery-2.jpg" alt="Нефтебаза и АЗС Б-52"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-gallery-image"} -->
<figure class="wp-block-image size-full b52-gallery-image"><img src="https://baza-b52.ru/wp-content/uploads/2019/04/gallery-3.jpg" alt="Нефтебаза и АЗС Б-52"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-gallery-image"} -->
<figure class="wp-block-image size-full b52-gallery-image"><img src="https://baza-b52.ru/wp-content/uploads/2019/04/gallery-4.jpg" alt="Нефтебаза и АЗС Б-52"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

<?php
/**
 * Title: Б-52 / Контакты и карта
 * Slug: b52-industrial/map
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull b52-section"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">КАК НАС НАЙТИ</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Кстово.<br>Рядом с М-7.</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Расположена в промзоне города Кстово в непосредственной близости от федеральной трассы М-7 «Волга» и нефтеперерабатывающего завода ЛУКОЙЛ, имеет асфальтированные подъездные пути. Адрес: Кстовская промзона, район ТЭЦ</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{{page:contact}}">Схемы проезда ↗</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-contact-box"} -->
<div class="wp-block-group b52-contact-box"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Телефон отдела продаж:</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"b52-contact-phone"} -->
<p class="b52-contact-phone"><a href="tel:+79871110052">+7 (987) 111-00-52</a></p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Наш Email адрес:</h3>
<!-- /wp:heading --><!-- wp:paragraph {"className":"b52-contact-phone"} -->
<p class="b52-contact-phone"><a href="mailto:bazab52@mail.ru">bazab52@mail.ru</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

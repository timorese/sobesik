<?php
/**
 * Title: Б-52 / Первый экран
 * Slug: b52-industrial/hero
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:cover {"url":"{{asset:hero-tanker.webp}}","dimRatio":40,"customOverlayColor":"#0e1114","minHeight":760,"align":"full","className":"b52-hero","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull b52-hero" style="min-height:760px"><img class="wp-block-cover__image-background" alt="" src="{{asset:hero-tanker.webp}}" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-40 has-background-dim" style="background-color:#0e1114"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-hero-inner","align":"wide"} -->
<div class="wp-block-group alignwide b52-hero-inner"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">Б-52 / КСТОВО / С 2000 ГОДА</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Продажа<br>нефтепродуктов<br>и сжиженного<br>газа</h1>
<!-- /wp:heading --><!-- wp:paragraph {"className":"b52-lead"} -->
<p class="b52-lead">на крупнооптовом, мелкооптовом и розничных рынках Нижнего Новгорода и области.</p>
<!-- /wp:paragraph --><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#contacts">Оставить заявку ↗</a></div>
<!-- /wp:button --><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#services">Наши услуги</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-hero-stats"} -->
<div class="wp-block-group b52-hero-stats"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>2000</strong><br>год основания</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>700 м³</strong><br>резервуарный парк</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>М-7</strong><br>трасса «Волга»</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->');

<?php
/**
 * Title: Б-52 / Услуги
 * Slug: b52-industrial/services
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section","layout":{"type":"constrained"},"anchor":"services"} -->
<div id="services" class="wp-block-group alignfull b52-section"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">01 / НАШИ УСЛУГИ</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Всё для<br>уверенного пути.</h2>
<!-- /wp:heading --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/sale.jpg}}" width="720" height="480" alt="Продажа нефтепродуктов"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">01</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:sale}}">Продажа нефтепродуктов</a></h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Торговля нефтепродуктами и сжиженным газом на крупнооптовом, мелкооптовом и розничных рынках.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:sale}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/storage.jpg}}" width="720" height="480" alt="Ответственное хранение нефтепродуктов"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">02</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:storage}}">Ответственное хранение нефтепродуктов</a></h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Это позволит вам избежать сезонного колебания цен и оградить бизнес от возможных убытков.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:storage}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/weigh.jpg}}" width="720" height="480" alt="Автовесы для грузовых автомобилей"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">03</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:weigh}}">Автовесы для грузовых автомобилей</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:weigh}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/azs.jpg}}" width="720" height="480" alt="АЗС «Б52»"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">04</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:azs}}">АЗС «Б52»</a></h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Предлагаем своим клиентам качественные бензины АИ-92, АИ-95, дизельное топливо. Заключаем контракты с организациями и компаниями.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:azs}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/parking.jpg}}" width="720" height="480" alt="Автомобильная стоянка грузовых автомобилей"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">05</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:parking}}">Автомобильная стоянка грузовых автомобилей</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:parking}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-service-card"} -->
<div class="wp-block-group b52-service-card"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"b52-service-photo"} -->
<figure class="wp-block-image size-full b52-service-photo"><img src="{{asset:cards/cement.jpg}}" width="720" height="480" alt="Цемент"/></figure>
<!-- /wp:image --><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-card-body"} -->
<div class="wp-block-group b52-card-body"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">06</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="{{page:cement}}">Цемент</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:group --><!-- wp:paragraph {"className":"b52-card-link"} -->
<p class="b52-card-link"><a href="{{page:cement}}">Подробнее <span aria-hidden="true">↗</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

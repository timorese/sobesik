<?php
/**
 * Title: Б-52 / Форма заявки
 * Slug: b52-industrial/contact
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-contact","layout":{"type":"constrained"},"anchor":"contacts","backgroundColor":"accent"} -->
<div id="contacts" class="wp-block-group alignfull b52-section b52-contact has-accent-background-color has-background"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">СВЯЖИТЕСЬ С НАМИ</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Оставьте<br>заявку</h2>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>ЕСТЬ ВОПРОСЫ? НАПИШИТЕ НАМ НА ПОЧТУ: <a href="mailto:bazab52@mail.ru">BAZAB52@mail.ru</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph {"className":"b52-contact-phone"} -->
<p class="b52-contact-phone"><a href="tel:+79871110052">+7 (987) 111-00-52</a></p>
<!-- /wp:paragraph --><!-- wp:paragraph -->
<p>Кстовская промзона, район ТЭЦ</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:shortcode -->
[b52_contact_form]
<!-- /wp:shortcode --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

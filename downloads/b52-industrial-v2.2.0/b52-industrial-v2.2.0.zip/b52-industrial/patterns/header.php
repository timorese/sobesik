<?php
/**
 * Title: Б-52 / header
 * Slug: b52-industrial/header
 * Categories: b52-layouts
 * Inserter: no
 */
echo b52_resolve_content('<!-- wp:group {"layout":{"type":"constrained"},"className":"b52-header"} -->
<div class="wp-block-group b52-header"><!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
<div class="wp-block-group alignwide"><!-- wp:image {"width":"150px","sizeSlug":"full","linkDestination":"custom"} -->
<figure class="wp-block-image size-full is-resized"><a href="{{page:home}}"><img src="{{asset:logo-header-white.svg}}" alt="Б52 — гарант счастливого пути" style="width:150px"/></a></figure>
<!-- /wp:image --><!-- wp:navigation {"overlayMenu":"mobile","layout":{"type":"flex","justifyContent":"right"}} -->
<!-- wp:navigation-link {"label":"Главная","url":"{{page:home}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"Нефтепродукты","url":"{{page:sale}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"Хранение","url":"{{page:storage}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"АЗС","url":"{{page:azs}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"База","url":"{{page:base}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"О компании","url":"{{page:about}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"Новости","url":"{{page:news}}","kind":"custom"} /--><!-- wp:navigation-link {"label":"Контакты","url":"{{page:contact}}","kind":"custom"} /-->
<!-- /wp:navigation --><!-- wp:paragraph {"className":"b52-header-phone"} -->
<p class="b52-header-phone"><a href="tel:+79871110052">+7 (987) 111-00-52</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

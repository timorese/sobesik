<?php
/**
 * Title: Б-52 / Преимущества
 * Slug: b52-industrial/advantages
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-benefits","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull b52-section b52-benefits"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">ВАЖНОЕ О НАС</p>
<!-- /wp:paragraph --><!-- wp:heading -->
<h2 class="wp-block-heading">Собственная<br>инфраструктура</h2>
<!-- /wp:heading --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"b52-lead"} -->
<p class="b52-lead">Основным направлением деятельности компании является торговля светлыми и темными нефтепродуктами и сжиженным газом на крупнооптовом, мелкооптовом и розничных рынках.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Собственная нефтебаза</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Собственная АЗС</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>АВТОВЕСЫ</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Ответственное хранение</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Собственный автопарк</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Автостоянка для грузового транспорта</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Бесперебойное обеспечение топливом своих клиентов</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

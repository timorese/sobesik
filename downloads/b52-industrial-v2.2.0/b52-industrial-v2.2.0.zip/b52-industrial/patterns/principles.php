<?php
/**
 * Title: Б-52 / Принципы
 * Slug: b52-industrial/principles
 * Categories: b52-sections
 */
echo b52_resolve_content('<!-- wp:group {"align":"full","className":"b52-section b52-principles","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull b52-section b52-principles"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-container","align":"wide"} -->
<div class="wp-block-group alignwide b52-container"><!-- wp:paragraph {"className":"b52-eyebrow"} -->
<p class="b52-eyebrow">НАШИ ПРИНЦИПЫ</p>
<!-- /wp:paragraph --><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-principle"} -->
<div class="wp-block-group b52-principle"><!-- wp:paragraph {"className":"b52-index"} -->
<p class="b52-index">01</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Внимательное отношение</h3>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-principle"} -->
<div class="wp-block-group b52-principle"><!-- wp:paragraph {"className":"b52-index"} -->
<p class="b52-index">02</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ответственность</h3>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-principle"} -->
<div class="wp-block-group b52-principle"><!-- wp:paragraph {"className":"b52-index"} -->
<p class="b52-index">03</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Честность</h3>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-principle"} -->
<div class="wp-block-group b52-principle"><!-- wp:paragraph {"className":"b52-index"} -->
<p class="b52-index">04</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Квалифицированный персонал</h3>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"constrained"},"className":"b52-principle"} -->
<div class="wp-block-group b52-principle"><!-- wp:paragraph {"className":"b52-index"} -->
<p class="b52-index">05</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Высокое качество продукции и обслуживания</h3>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->');

document.querySelectorAll('form').forEach(f=>f.addEventListener('submit',e=>e.preventDefault()));
document.querySelectorAll('.wp-block-navigation').forEach(nav=>{
 const panel=nav.querySelector('.wp-block-navigation__responsive-container');
 const open=nav.querySelector('.wp-block-navigation__responsive-container-open');
 const close=nav.querySelector('.wp-block-navigation__responsive-container-close');
 if(!panel||!open||!close)return;
 const hide=()=>{panel.classList.remove('is-menu-open','has-modal-open');open.setAttribute('aria-expanded','false');document.body.style.overflow='';open.focus();};
 open.addEventListener('click',()=>{panel.classList.add('is-menu-open','has-modal-open');open.setAttribute('aria-expanded','true');document.body.style.overflow='hidden';close.focus();});
 close.addEventListener('click',hide);
 panel.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
});